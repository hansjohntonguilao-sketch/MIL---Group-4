const result = document.getElementById("result");
const revealBtn = document.getElementById("revealBtn");
const bossBtn = document.getElementById("bossBtn");

const powers = [
  ["🔥 POWER UNLOCKED", "We may look calm, but give us a deadline and suddenly everyone becomes productive."],
  ["🏆 SECRET FORMULA", "Teamwork + creativity + a little panic = somehow, we get it done."],
  ["⚡ TEAM MODE: ON", "Eight minds, one mission, zero plans to give up."],
  ["💀 FINAL BOSS ENERGY", "If the task is hard, we simply stare at it until it becomes easier."],
  ["✨ PLOT TWIST", "We came for the grade. We stayed for the memories and inside jokes."]
];

const bosses = [
  "Nobody is in charge. We are a democracy. 😭",
  "The deadline is in charge. We just work for it. 💀",
  "The quiet member is secretly the boss. 👀",
  "Whoever has the file is the boss. Please don't lose the file. 😂",
  "The group chat is the real leader. 📱"
];

revealBtn.addEventListener("click", () => {
  const [title, text] = powers[Math.floor(Math.random() * powers.length)];
  result.innerHTML = `
    <span class="result-icon">✨</span>
    <h2>${title}</h2>
    <p>${text}</p>
  `;
});

bossBtn.addEventListener("click", () => {
  const text = bosses[Math.floor(Math.random() * bosses.length)];
  result.innerHTML = `
    <span class="result-icon">👑</span>
    <h2>THE VERDICT</h2>
    <p>${text}</p>
  `;
});
